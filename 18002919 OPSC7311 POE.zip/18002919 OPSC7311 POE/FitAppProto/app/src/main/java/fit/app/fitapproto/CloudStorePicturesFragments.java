package fit.app.fitapproto;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;

import fit.app.fitapproto.Models.PictureModel;
import fit.app.fitapproto.Permissions.PicturePermission;


public class CloudStorePicturesFragments extends Fragment {
    public static final int PICK_CODE = 104;
    public static final int REQUEST_CODE = 101;
    FirebaseAuth mAuth;
    FirebaseUser currentUser;
    Uri pictureData;
    Button chooseCloudPicture, storeCloudPicture;
    ImageView cloudPicturePane;
    EditText cloudPictureName;
    Bitmap pictureToStore;
    String storedPictureUri;
    private StorageReference mStorageRef;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("FoodPictures");

    private static CloudStorePicturesFragments instance;

    public static CloudStorePicturesFragments getInstance() {
        if (instance == null)
            return new CloudStorePicturesFragments();
        return instance;

    }

    public CloudStorePicturesFragments() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mStorageRef = FirebaseStorage.getInstance().getReference("FoodPictures");
        View view = inflater.inflate(R.layout.fragment_cloud_store_pictures_fragments, container, false);
        chooseCloudPicture = view.findViewById(R.id.img_chooseCloudPicture);
        storeCloudPicture = view.findViewById(R.id.img_saveCloudPicture);
        cloudPicturePane = view.findViewById(R.id.img_cloudPicturePane);
        cloudPictureName = view.findViewById(R.id.et_nameCloudPicture);
        mAuth = FirebaseAuth.getInstance();

        chooseCloudPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                if (!PicturePermission.hasPermissions(getContext())) {
                    ActivityCompat.requestPermissions(getActivity(), permissions, REQUEST_CODE);
                } else {
                    chooseImage();
                }
            }
        });

        storeCloudPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                if (!PicturePermission.hasPermissions(getContext())) {
                    ActivityCompat.requestPermissions(getActivity(), permissions, REQUEST_CODE);
                } else {
                    storeImage();
                }
            }
        });
        return view;
    }

    private void chooseImage() {
        Intent chooseImage = new Intent(Intent.ACTION_GET_CONTENT);
        chooseImage.setType("image/*");
        startActivityForResult(Intent.createChooser(chooseImage, "Pick an image"), PICK_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CODE && data != null) {
            pictureData = data.getData();

            try {
                pictureToStore = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), pictureData);
            } catch (IOException e) {
                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            cloudPicturePane.setImageBitmap(pictureToStore);
        }
    }

    private String GetFileExtensions(Uri uri) {
        ContentResolver contentResolver = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void storeImage() {
        try {
            if (pictureData != null) {
                final StorageReference fileRef = mStorageRef.child(System.currentTimeMillis() + "." + GetFileExtensions(pictureData));

                UploadTask uploadTask = fileRef.putFile(pictureData);

                Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        return fileRef.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if (task.isSuccessful()) {
                            currentUser = mAuth.getCurrentUser();
                            storedPictureUri = task.getResult().toString();
                            PictureModel pictureModel = new PictureModel(cloudPictureName.getText().toString().trim(), storedPictureUri);

                            String uploadID = myRef.push().getKey();
                            myRef.child(currentUser.getUid()).child(uploadID).setValue(pictureModel);

                            Toast.makeText(getContext(), "Image Loaded to Cloud", Toast.LENGTH_SHORT).show();

                            cloudPicturePane.setImageResource(android.R.color.transparent);
                            cloudPictureName.getText().clear();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}