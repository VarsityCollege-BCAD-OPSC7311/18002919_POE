package fit.app.fitapproto.Models;

public class PictureModel {
    String pictureName;
    String pictureUrl;
    String userID;

    public PictureModel(){}

    //cloud database
    public PictureModel(String pictureName, String pictureUrl) {
        this.pictureName = pictureName;
        this.pictureUrl = pictureUrl;
    }

    //cloud database with user
    public PictureModel(String pictureName, String pictureUrl, String userID) {
        this.pictureName = pictureName;
        this.pictureUrl = pictureUrl;
        this.userID = userID;
    }

    public String getPictureName() {
        return pictureName;
    }

    public void setPictureName(String pictureName) {
        this.pictureName = pictureName;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
