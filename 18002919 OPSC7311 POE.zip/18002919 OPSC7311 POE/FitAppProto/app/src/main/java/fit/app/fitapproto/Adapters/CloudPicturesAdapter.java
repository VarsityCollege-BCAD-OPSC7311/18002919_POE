package fit.app.fitapproto.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import fit.app.fitapproto.Models.PictureModel;
import fit.app.fitapproto.R;

public class CloudPicturesAdapter extends RecyclerView.Adapter<CloudPicturesAdapter.MyViewHolder>{
    Context context;
    List<PictureModel> pictureList= new ArrayList<>();
    PictureModel pictureModel;

    public CloudPicturesAdapter(){}

    public CloudPicturesAdapter(Context context, List<PictureModel> pictureList){
        this.context = context;
        this.pictureList = pictureList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(context).inflate(R.layout.pictures_items,parent,false);
        return new MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        PictureModel pictureModel = pictureList.get(position);

        holder.cloudPictureName.setText(pictureModel.getPictureName());

        Picasso.get().load(pictureModel.getPictureUrl()).fit().centerCrop().into(holder.cloudPicture);
    }

    @Override
    public int getItemCount() {
        return pictureList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        ImageView cloudPicture;
        TextView cloudPictureName;
        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);

            cloudPicture = itemView.findViewById(R.id.adapter_image);
            cloudPictureName = itemView.findViewById(R.id.adapter_imageName);
        }
    }}
