package fit.app.fitapproto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CloudPictures extends AppCompatActivity {

    Button storeCloudPictures,viewCloudPictures;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloud_pictures);
        storeCloudPictures = findViewById(R.id.storeCloudPictures);
        viewCloudPictures = findViewById(R.id.viewCloudPictures);

        storeCloudPictures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.load_cloudPicturePlaceHolder,CloudStorePicturesFragments.getInstance());
                transaction.commitAllowingStateLoss();
            }
        });
        viewCloudPictures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.load_cloudPicturePlaceHolder,CloudViewPicturesFragment.getInstance());
                transaction.commitAllowingStateLoss();
            }
        });
    }
}