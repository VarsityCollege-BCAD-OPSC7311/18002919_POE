package fit.app.fitapproto;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import fit.app.fitapproto.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    double doub1, doub2, doub3, doub4, doub5, doub6;
    int var1, var2, var3, var4, var5, var6;
    Switch Convert;
    Button logIn, newUser, Create,cancel,weightAdd,weightCancel,returnUser,edit, graphReturn, graphShow;
    ImageButton logOut, Profile,foodDaily, weightDaily, Details, Settings, Stats;
    CalendarView curDate;
    EditText email, password, txbOther,Weight,Height,age,Calories,GoalWeight,GoalCalories, GoalHeight, curWeight;
    TextView startWeight,curHeight,DispAge,DispGender,caloricIntake,goalWeight,goalCalInt,weightDet,heightDet,goalWeightDet,goalHeightDet,todayWeight, labUpload, labProfile, labMeas, labSet, labLog, labStat;
    FirebaseUser curUser;
    RadioButton Male,Female,Other;
    CardView loginCardView,detailsCardView,profileCardView,dailyCardView, graphCardView;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseAuth mAuth;
    String Gender,measSyst, saveGend, save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        labUpload= findViewById(R.id.upldpic);
        labProfile= findViewById(R.id.custProf);
        labMeas= findViewById(R.id.recMeas);
        labSet= findViewById(R.id.sets);
        labLog= findViewById(R.id.log);
        labStat= findViewById(R.id.vwSta);
        logIn= findViewById(R.id.btnLogin);
        newUser= findViewById(R.id.btnRegister);
        graphReturn= findViewById(R.id.btnGraphReturn);
        graphShow= findViewById(R.id.btnGraph);
        logOut= findViewById(R.id.ibtnLogout);
        Create= findViewById(R.id.btnAdd);
        Profile= findViewById(R.id.ibtnCust);
        foodDaily= findViewById(R.id.ibtnUpload);
        weightDaily= findViewById(R.id.ibtnMeas);
        Convert = findViewById(R.id.swConvert);
        Details= findViewById(R.id.ibtnSats);
        Settings= findViewById(R.id.ibtnSettings);
        cancel= findViewById(R.id.btnCancel);
        weightAdd= findViewById(R.id.btnAddDaily);
        weightCancel= findViewById(R.id.btnCancelDaily);
        returnUser= findViewById(R.id.btnReturn);
        edit= findViewById(R.id.btnEdit);
        curDate= findViewById(R.id.dateCurrent);
        email= findViewById(R.id.inpEmail);
        password= findViewById(R.id.inpPassword);
        txbOther= findViewById(R.id.inpOther);
        Weight= findViewById(R.id.numWeight);
        Height= findViewById(R.id.numHeight);
        age= findViewById(R.id.numAge);
        Calories= findViewById(R.id.numCalory);
        GoalWeight= findViewById(R.id.numGWeight);
        GoalCalories= findViewById(R.id.numGCalory);
        GoalHeight= findViewById(R.id.numGHeight);
        curWeight= findViewById(R.id.numTodayWeight);
        startWeight= findViewById(R.id.txtWeightDis);
        curHeight= findViewById(R.id.txtHeightDis);
        DispAge= findViewById(R.id.txtAgeDis);
        DispGender= findViewById(R.id.txtGenderDis);
        caloricIntake= findViewById(R.id.txtCaloryIntake);
        goalWeight= findViewById(R.id.txtGoalWeightDis);
        goalCalInt= findViewById(R.id.txtGoalCaloryIntakeDis);
        weightDet= findViewById(R.id.lblWeight);
        heightDet= findViewById(R.id.lblHeight);
        goalWeightDet= findViewById(R.id.lblGWeight);
        goalHeightDet= findViewById(R.id.lblGHeight);
        todayWeight= findViewById(R.id.txtKilogram);
        curUser= mAuth.getCurrentUser();
        Male= findViewById(R.id.radMale);
        Female= findViewById(R.id.radFemale);
        Other= findViewById(R.id.radOther);
        loginCardView= findViewById(R.id.cardview_login);
        detailsCardView= findViewById(R.id.cardview_Details);
        profileCardView= findViewById(R.id.cardview_Profile);
        dailyCardView= findViewById(R.id.cardview_Daily);
        graphCardView= findViewById(R.id.cardview_Graph);
        measSyst= "Metric";
        Gender= "Male";

        BarChart chart = (BarChart) findViewById(R.id.chart);

        BarData data = new BarData(getXAxisValues(), getDataSet());
        chart.setData(data);
        chart.setDescription("My Chart");
        chart.animateXY(2000, 2000);
        chart.invalidate();

        if (curUser != null)
        {
            loginCardView.setVisibility(View.GONE);
            logOut.setEnabled(true);
            Details.setEnabled(true);
            weightDaily.setEnabled(true);
            foodDaily.setEnabled(true);
            Profile.setEnabled(true);
            Settings.setEnabled(true);
            Settings.setVisibility(View.VISIBLE);
            logOut.setVisibility(View.VISIBLE);
            Details.setVisibility(View.VISIBLE);
            weightDaily.setVisibility(View.VISIBLE);
            foodDaily.setVisibility(View.VISIBLE);
            Profile.setVisibility(View.VISIBLE);
            labUpload.setVisibility(View.VISIBLE);
            labProfile.setVisibility(View.VISIBLE);
            labMeas.setVisibility(View.VISIBLE);
            labSet.setVisibility(View.VISIBLE);
            labLog.setVisibility(View.VISIBLE);
            labStat.setVisibility(View.VISIBLE);
        }
        else
        {
            loginCardView.setVisibility(View.VISIBLE);
            logOut.setEnabled(false);
            Details.setEnabled(false);
            weightDaily.setEnabled(false);
            foodDaily.setEnabled(false);
            Profile.setEnabled(false);
            Settings.setEnabled(false);
            Settings.setVisibility(View.GONE);
            logOut.setVisibility(View.GONE);
            Details.setVisibility(View.GONE);
            weightDaily.setVisibility(View.GONE);
            foodDaily.setVisibility(View.GONE);
            Profile.setVisibility(View.GONE);
            labUpload.setVisibility(View.GONE);
            labProfile.setVisibility(View.GONE);
            labMeas.setVisibility(View.GONE);
            labSet.setVisibility(View.GONE);
            labLog.setVisibility(View.GONE);
            labStat.setVisibility(View.GONE);
        }
        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String enteredEmail = email.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();
                mAuth.createUserWithEmailAndPassword(enteredEmail, enteredPassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this, "User "
                                            + Objects.requireNonNull(mAuth.getCurrentUser()).getEmail() + " has joined the battle", Toast.LENGTH_SHORT).show();
                                }
                                else {
                                    Toast.makeText(MainActivity.this, "Someone with this name already exists", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

        });

        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredEmail = email.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();

                mAuth.signInWithEmailAndPassword(enteredEmail,enteredPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this, "Welcome back " +
                                    Objects.requireNonNull(mAuth.getCurrentUser()).getEmail()+", we missed you", Toast.LENGTH_SHORT).show();
                            loginCardView.setVisibility(View.GONE);
                            logOut.setEnabled(true);
                            Details.setEnabled(true);
                            weightDaily.setEnabled(true);
                            foodDaily.setEnabled(true);
                            Profile.setEnabled(true);
                            Settings.setEnabled(false);
                            Settings.setVisibility(View.VISIBLE);
                            logOut.setVisibility(View.VISIBLE);
                            Details.setVisibility(View.VISIBLE);
                            weightDaily.setVisibility(View.VISIBLE);
                            foodDaily.setVisibility(View.VISIBLE);
                            Profile.setVisibility(View.VISIBLE);
                            labUpload.setVisibility(View.VISIBLE);
                            labProfile.setVisibility(View.VISIBLE);
                            labMeas.setVisibility(View.VISIBLE);
                            labSet.setVisibility(View.VISIBLE);
                            labLog.setVisibility(View.VISIBLE);
                            labStat.setVisibility(View.VISIBLE);

                        }

                        else
                        {
                            Toast.makeText(MainActivity.this, "Oh nose, now reality will collapse", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e)
                    {
                        Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Toast.makeText(MainActivity.this, "See you soon", Toast.LENGTH_SHORT).show();
                loginCardView.setVisibility(View.VISIBLE);
                logOut.setEnabled(false);
                Details.setEnabled(false);
                weightDaily.setEnabled(false);
                foodDaily.setEnabled(false);
                Profile.setEnabled(false);
                Settings.setEnabled(false);
                Settings.setVisibility(View.GONE);
                logOut.setVisibility(View.GONE);
                Details.setVisibility(View.GONE);
                weightDaily.setVisibility(View.GONE);
                foodDaily.setVisibility(View.GONE);
                Profile.setVisibility(View.GONE);
                labUpload.setVisibility(View.GONE);
                labProfile.setVisibility(View.GONE);
                labMeas.setVisibility(View.GONE);
                labSet.setVisibility(View.GONE);
                labLog.setVisibility(View.GONE);
                labStat.setVisibility(View.GONE);

            }
        });

        Male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Male.isChecked())
                {
                    txbOther.setEnabled(false);
                    Gender ="Male";
                    Female.setChecked(false);
                    Other.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });
        Female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Female.isChecked())
                {
                    txbOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Other.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });
        Other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Other.isChecked())
                {
                    txbOther.setEnabled(true);
                    Gender = txbOther.getText().toString();
                    Female.setChecked(false);
                    Male.setChecked(false);
                    Toast.makeText(MainActivity.this,"You Chose: " + Gender, Toast.LENGTH_SHORT).show();
                }

            }
        });

        Details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailsCardView.setVisibility(View.VISIBLE);
                logOut.setEnabled(false);
                Details.setEnabled(false);
                weightDaily.setEnabled(false);
                foodDaily.setEnabled(false);
                Profile.setEnabled(false);
                Settings.setEnabled(false);


                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserData data = new UserData();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        data = snapshot.getValue(UserData.class);
                        if(snapshot.exists()) {
                            Weight.setText(data.getUserWeight());
                            Height.setText(data.getUserHeight());
                            age.setText(data.getUserAge());
                            Calories.setText(data.getCaloricIntake());
                            GoalWeight.setText(data.getGoalWeight());
                            GoalCalories.setText(data.getGoalCalories());
                            GoalHeight.setText(data.getGoalHeight());
                            if(data.getSystem() == null)
                            {
                                measSyst = "Metric";
                            }
                            else
                            {
                                measSyst = data.getSystem();
                            }

                            if(data.getGender() == null)
                            {
                                saveGend = "Male";
                            }
                            else
                            {
                                saveGend = data.getGender();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
                if(measSyst.equals("Metric"))
                {
                    Convert.setChecked(false);
                    Convert.setText(measSyst);
                    weightDet.setText("Kg");
                    heightDet.setText("cm");
                    goalWeightDet.setText("Kg");
                    goalHeightDet.setText("cm");
                }
                else if (measSyst.equals("Imperial"))
                {
                    Convert.setChecked(true);
                    Convert.setText(measSyst);
                    weightDet.setText("lb");
                    heightDet.setText("Inches");
                    goalWeightDet.setText("lb");
                    goalHeightDet.setText("Inches");
                }
                else
                {
                    Toast.makeText(MainActivity.this, measSyst, Toast.LENGTH_SHORT).show();
                }

                if(saveGend =="Male"){
                    txbOther.setEnabled(false);
                    Gender ="Male";
                    Male.setChecked(true);
                    Female.setChecked(false);
                    Other.setChecked(false);
                }
                else if(saveGend == "Female"){
                    txbOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Female.setChecked(true);
                    Other.setChecked(false);
                }
                else {
                    txbOther.setEnabled(true);
                    Gender = saveGend;
                    txbOther.setText(Gender);
                    Male.setChecked(false);
                    Female.setChecked(false);
                    Other.setChecked(true);
                }
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                detailsCardView.setVisibility(View.VISIBLE);
                profileCardView.setVisibility(View.GONE);
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserData data = new UserData();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        data = snapshot.getValue(UserData.class);
                        if(snapshot.exists()) {
                            Weight.setText(data.getUserWeight());
                            Height.setText(data.getUserHeight());
                            age.setText(data.getUserAge());
                            Calories.setText(data.getCaloricIntake());
                            GoalWeight.setText(data.getGoalWeight());
                            GoalCalories.setText(data.getGoalCalories());
                            GoalHeight.setText(data.getGoalHeight());
                            if(data.getSystem() == null)
                            {
                                measSyst = "Metric";
                            }
                            else
                            {
                                measSyst = data.getSystem();
                            }
                            if(data.getGender() == null)
                            {
                                saveGend = "Male";
                            }
                            else
                            {
                                saveGend = data.getGender();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
                if(measSyst == "Metric")
                {
                    Convert.setChecked(false);
                    Convert.setText(measSyst);
                    weightDet.setText("Kg");
                    heightDet.setText("cm");
                    goalWeightDet.setText("Kg");
                    goalHeightDet.setText("cm");
                }
                else if (measSyst == "Imperial")
                {
                    Convert.setChecked(true);
                    Convert.setText(measSyst);
                    weightDet.setText("lb");
                    heightDet.setText("Inches");
                    goalWeightDet.setText("lb");
                    goalHeightDet.setText("Inches");
                }
                if(saveGend == "Male"){
                    txbOther.setEnabled(false);
                    Gender ="Male";
                    Male.setChecked(true);
                    Female.setChecked(false);
                    Other.setChecked(false);
                }
                else if(saveGend == "Female"){
                    txbOther.setEnabled(false);
                    Gender ="Female";
                    Male.setChecked(false);
                    Female.setChecked(true);
                    Other.setChecked(false);
                }
                else {
                    txbOther.setEnabled(true);
                    Gender = saveGend;
                    txbOther.setText(Gender);
                    Male.setChecked(false);
                    Female.setChecked(false);
                    Other.setChecked(true);
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailsCardView.setVisibility(View.GONE);
                logOut.setEnabled(true);
                Details.setEnabled(true);
                weightDaily.setEnabled(true);
                foodDaily.setEnabled(true);
                Profile.setEnabled(true);
                Settings.setEnabled(true);

            }
        });

        foodDaily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Picture uploader", Toast.LENGTH_SHORT).show();
                Intent openImage = new Intent(getApplicationContext(),CloudPictures.class);
                startActivity(openImage);

            }
        });
        Settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Sorry this feature is currently unavailable", Toast.LENGTH_SHORT).show();
            }
        });
        weightDaily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dailyCardView.setVisibility(View.VISIBLE);
                logOut.setEnabled(false);
                Details.setEnabled(false);
                weightDaily.setEnabled(false);
                foodDaily.setEnabled(false);
                Profile.setEnabled(false);
                Settings.setEnabled(false);
            }
        });
        weightCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dailyCardView.setVisibility(View.GONE);
                logOut.setEnabled(true);
                Details.setEnabled(true);
                weightDaily.setEnabled(true);
                foodDaily.setEnabled(true);
                Profile.setEnabled(true);
                Settings.setEnabled(true);
            }
        });

        weightAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat date = new SimpleDateFormat("dd MM yyyy");
                SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy");
                String weightCurrent = curWeight.getText().toString();
                String dateCurrent = date.format(new Date(curDate.getDate()));
                String stoDateCurrent = date2.format(new Date(curDate.getDate()));
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                WeightInput dailyWeight = new WeightInput(weightCurrent,stoDateCurrent);
                if(weightCurrent.isEmpty() )
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    refUser.child("Daily weight").child(dateCurrent).setValue(dailyWeight);
                    Toast.makeText(MainActivity.this, "Stored weight " + weightCurrent + "Kg on: " + stoDateCurrent, Toast.LENGTH_SHORT).show();
                    dailyCardView.setVisibility(View.GONE);
                    logOut.setEnabled(true);
                    Details.setEnabled(true);
                    weightDaily.setEnabled(true);
                    foodDaily.setEnabled(true);
                    Profile.setEnabled(true);
                    Settings.setEnabled(true);
                }
            }
        });
        graphReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.VISIBLE);
                graphCardView.setVisibility(View.GONE);
            }
        });

        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.VISIBLE);
                logOut.setEnabled(false);
                Details.setEnabled(false);
                weightDaily.setEnabled(false);
                foodDaily.setEnabled(false);
                Profile.setEnabled(false);
                Settings.setEnabled(false);

                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                refUser.child("User Info").addValueEventListener(new ValueEventListener() {

                    UserData info = new UserData();
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        info = snapshot.getValue(UserData.class);
                        if(snapshot.exists()) {

                            doub1 =Double.parseDouble(info.getUserWeight());
                            var1 = (int)doub1;
                            doub2 =Double.parseDouble(info.getUserHeight());
                            var2 = (int)doub2;
                            doub3 =Double.parseDouble(info.getCaloricIntake());
                            var3 = (int)doub3;
                            doub4 =Double.parseDouble(info.getGoalWeight());
                            var4 = (int)doub4;
                            doub5 =Double.parseDouble(info.getGoalHeight());
                            var5 = (int)doub5;
                            doub6 =Double.parseDouble(info.getGoalCalories());
                            var6 = (int)doub6;

                            BarChart chart = findViewById(R.id.chart);
                            BarData data = new BarData(getXAxisValues(), getDataSet());
                            chart.setData(data);
                            chart.animateXY(2000, 2000);
                            chart.invalidate();

                            if(measSyst == "Metric") {
                                startWeight.setText("Starter Weight: " + info.getUserWeight() + "Kg");
                                curHeight.setText("Height: " + info.getUserHeight() + "cm");
                                DispAge.setText("Age: " + info.getUserAge());
                                DispGender.setText("Gender: " + info.getGender());
                                caloricIntake.setText("Caloric Intake: " + info.getCaloricIntake() + " Calories");
                                goalWeight.setText("Goal Weight: " + info.getGoalWeight() + "Kg");
                                goalCalInt.setText("Goal Caloric Intake: " + info.getGoalCalories() + " Calories");
                            }
                            else if(measSyst == "Imperial") {
                                startWeight.setText("Starter Weight: " + info.getUserWeight() + "lb");
                                curHeight.setText("Height: " + info.getUserHeight() + " Inches");
                                DispAge.setText("Age: " + info.getUserAge());
                                DispGender.setText("Gender: " + info.getGender());
                                caloricIntake.setText("Caloric Intake: " + info.getCaloricIntake() + " Calories");
                                goalWeight.setText("Goal Weight: " + info.getGoalWeight() + "lb");
                                goalCalInt.setText("Goal Caloric Intake: " + info.getGoalCalories() + " Calories");
                            }
                        }
                        else{
                            startWeight.setText("Starter Weight: no Value Entered" );
                            curHeight.setText("Height: no Value Entered ");
                            DispAge.setText("Age: no Value Entered " );
                            DispGender.setText("Gender: no Value Entered " );
                            caloricIntake.setText("Caloric Intake: no Value Entered ");
                            goalWeight.setText("Goal Weight: no Value Entered " );
                            goalCalInt.setText("Goal Caloric Intake: no Value Entered ");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        graphShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.GONE);
                graphCardView.setVisibility(View.VISIBLE);
            }
        });

        returnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileCardView.setVisibility(View.GONE);
                logOut.setEnabled(true);
                Details.setEnabled(true);
                weightDaily.setEnabled(true);
                foodDaily.setEnabled(true);
                Profile.setEnabled(true);
                Settings.setEnabled(true);
            }
        });

        Convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!Convert.isChecked()){
                    measSyst = "Metric";
                    Convert.setText(measSyst);
                    String metricWeight=Weight.getText().toString().trim();
                    String metricHeight=Height.getText().toString().trim();
                    String metricGWeight=GoalWeight.getText().toString().trim();
                    if(!metricWeight.isEmpty() && !metricHeight.isEmpty() && !metricGWeight.isEmpty()) {
                        Weight.setText(String.valueOf(Double.parseDouble(metricWeight) / 2.20462));
                        Height.setText(String.valueOf(Double.parseDouble(metricHeight) / 0.3937));
                        GoalWeight.setText(String.valueOf(Double.parseDouble(metricGWeight) / 2.20462));
                    }
                    weightDet.setText("Kg");
                    heightDet.setText("cm");
                    goalWeightDet.setText("Kg");
                }
                else if(Convert.isChecked()){
                    measSyst = "Imperial";
                    Convert.setText(measSyst);
                    String imperialWeight=Weight.getText().toString().trim();
                    String imperialHeight=Height.getText().toString().trim();
                    String imperialGWeight=GoalWeight.getText().toString().trim();
                    if(!imperialWeight.isEmpty() && !imperialHeight.isEmpty() && !imperialGWeight.isEmpty()) {
                        Weight.setText(String.valueOf(Double.parseDouble(imperialWeight) * 2.20462));
                        Height.setText(String.valueOf(Double.parseDouble(imperialHeight) * 0.3937));
                        GoalWeight.setText(String.valueOf(Double.parseDouble(imperialGWeight) * 2.20462));
                    }
                    weightDet.setText("lb");
                    heightDet.setText("Inches");
                    goalWeightDet.setText("lb");
                }
            }
        });

        Create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userWeight = Weight.getText().toString().trim();
                String userHeight = Height.getText().toString();
                String userAge = age.getText().toString();
                String userCalorie = Calories.getText().toString();
                String goalWeightUser = GoalWeight.getText().toString();
                String goalCaloriesUser = GoalCalories.getText().toString();
                String goalHeightUser = GoalHeight.getText().toString();
                if(Other.isChecked())
                {
                    Gender = txbOther.getText().toString();
                }
                DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());
                UserData info = new UserData(userWeight, userHeight, userAge, userCalorie, goalWeightUser, goalCaloriesUser, goalHeightUser, Gender,measSyst);

                if(userWeight.isEmpty() || userHeight.isEmpty() || userAge.isEmpty() || userCalorie.isEmpty() || goalWeightUser.isEmpty()||goalCaloriesUser.isEmpty() || goalHeightUser.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    refUser.child("User Info").setValue(info);
                    Toast.makeText(MainActivity.this, "Your Info has been Added/Updated", Toast.LENGTH_SHORT).show();
                    detailsCardView.setVisibility(View.GONE);
                    logOut.setEnabled(true);
                    Details.setEnabled(true);
                    weightDaily.setEnabled(true);
                    foodDaily.setEnabled(true);
                    Profile.setEnabled(true);
                    Settings.setEnabled(true);
                }


            }
        });

    }

    @Override
    protected void onStart()
    {
        super.onStart();
        if(curUser != null)
        {

            Male.setEnabled(true);
            Gender = "Male";
            DatabaseReference refUser = database.getReference(mAuth.getCurrentUser().getUid());

            refUser.child("User Data").addValueEventListener(new ValueEventListener() {

                UserData data = new UserData();
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    data = snapshot.getValue(UserData.class);
                    if(snapshot.exists()) {


                        Weight.setText(data.getUserWeight());
                        Height.setText(data.getUserHeight());
                        age.setText(data.getUserAge());
                        Calories.setText(data.getCaloricIntake());
                        GoalWeight.setText(data.getGoalWeight());
                        GoalCalories.setText(data.getGoalCalories());
                        GoalHeight.setText(data.getGoalHeight());
                        if(data.getSystem() == null)
                        {
                            measSyst = "Metric";
                        }
                        else
                        {
                            measSyst = data.getSystem();
                        }
                        if(data.getGender() == null)
                        {
                            saveGend = "Male";
                        }
                        else
                        {
                            saveGend = data.getGender();
                        }

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }
    private ArrayList getDataSet() {
        ArrayList dataSets = null;

        ArrayList valueSet1 = new ArrayList();
        BarEntry v1e1 = new BarEntry(var1, 0); // Weight
        valueSet1.add(v1e1);
        BarEntry v1e2 = new BarEntry(var2, 1); // Height
        valueSet1.add(v1e2);
        BarEntry v1e3 = new BarEntry(var3, 2); // Calories
        valueSet1.add(v1e3);

        ArrayList valueSet2 = new ArrayList();
        BarEntry v2e1 = new BarEntry(var4, 0); // Weight
        valueSet2.add(v2e1);
        BarEntry v2e2 = new BarEntry(var5, 1); // Height
        valueSet2.add(v2e2);
        BarEntry v2e3 = new BarEntry(var6, 2); // Calories
        valueSet2.add(v2e3);

        BarDataSet barDataSet1 = new BarDataSet(valueSet1, "Current");
        barDataSet1.setColor(Color.rgb(0, 155, 0));
        BarDataSet barDataSet2 = new BarDataSet(valueSet2, "Goal");
        barDataSet2.setColor(Color.rgb(0, 0,155 ));

        dataSets = new ArrayList();
        dataSets.add(barDataSet1);
        dataSets.add(barDataSet2);
        return dataSets;
    }

    private ArrayList getXAxisValues() {
        ArrayList xAxis = new ArrayList();
        xAxis.add("Weight");
        xAxis.add("Height");
        xAxis.add("Calories");
        return xAxis;
    }
}