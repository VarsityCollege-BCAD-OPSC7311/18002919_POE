package fit.app.fitapproto;

public class UserData {
    private String UserWeight;
    private String UserHeight;
    private String UserAge;
    private String CaloricIntake;
    private String GoalWeight;
    private String GoalCalories;
    private String GoalHeight;
    private String Gender;
    private String System;

    public UserData(String userWeight, String userHeight, String userAge, String caloricIntake, String goalWeight, String goalCalories, String goalHeight, String gender, String system){
        UserWeight = userWeight;
        UserHeight = userHeight;
        UserAge = userAge;
        CaloricIntake = caloricIntake;
        GoalWeight = goalWeight;
        GoalCalories = goalCalories;
        GoalHeight = goalHeight;
        Gender = gender;
        System = system;
    }

    public UserData(){

    }

    public String getUserWeight() {
        return UserWeight;
    }

    public void setUserWeight(String userWeight) {
        UserWeight = userWeight;
    }

    public String getUserHeight() {
        return UserHeight;
    }

    public void setUserHeight(String userHeight) {
        UserHeight = userHeight;
    }

    public String getUserAge() {
        return UserAge;
    }

    public void setUserAge(String userAge) {
        UserAge = userAge;
    }

    public String getCaloricIntake() {
        return CaloricIntake;
    }

    public void setCaloricIntake(String caloricIntake) {
        CaloricIntake = caloricIntake;
    }

    public String getGoalWeight() {
        return GoalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        GoalWeight = goalWeight;
    }

    public String getGoalCalories() {
        return GoalCalories;
    }

    public void setGoalCalories(String goalCalories) {
        GoalCalories = goalCalories;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getSystem() {
        return System;
    }

    public void setSystem(String system) {
        System = system;
    }

    public String getGoalHeight(){return GoalHeight;}

    public void setGoalHeight(String goalHeight){GoalHeight = goalHeight;}
}
