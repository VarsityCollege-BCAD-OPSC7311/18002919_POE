package fit.app.fitapproto;

public class WeightInput {
    private String CurWeight;
    private String CurDate;

    public WeightInput(String curWeight, String curDate) {
        CurWeight = curWeight;
        CurDate = curDate;
    }

    public String getCurWeight() {
        return CurWeight;
    }

    public void setCurWeight(String curWeight) {
        CurWeight = curWeight;
    }

    public String getCurDate() {
        return CurDate;
    }

    public void setCurDate(String curDate) {
        CurDate = curDate;
    }
}
